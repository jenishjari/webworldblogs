"use strict";

// function site_js(params) {
//     alert("hi");
// }
$(document).ready(site_js());