<?php
/***********************************************************/
// Common options
/***********************************************************/
$prefix = 'freshcodes_content_';
$FC_META_BOXES[] = array(
	'id'		=> 'freshcodes_content_area',
	'title' 	=> esc_html__('FC - Content Options:', 'caliber'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Content Position:', 'caliber'),
			'id'      		=> "{$prefix}position",
			'type'    		=> 'radio',
			'std'			=> 'above',
			'options'		=> array(
				'none'		=> 'None',
				'above'		=> 'Above',
				'below'		=> 'Below',
			),
			'top_divider'	=> true
		),
	),
);
$prefix = 'freshcodes_page_';
$FC_META_BOXES[] = array(
	'id'		=> 'freshcodes_page_width_layout',
	'title' 	=> esc_html__('FC - Page Layout:', 'caliber'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Page Layout:', 'caliber'),
			'id'      		=> "{$prefix}layout",
			'type'    		=> 'radio',
			'std'			=> 'box',
			'options'		=> array(
				'box'		=> 'Box',
				'wide'		=> 'Wide',
			),
			'top_divider'	=> true
		),
	),
);
$prefix = 'freshcodes_sidebar_';
$FC_META_BOXES[] = array(
	'id'		=> 'freshcodes_posts_other_side',
	'title' 	=> esc_html__('FC - Sidebar Options:', 'caliber'),
	'pages' 	=> array( 'page' ),	
	'context' 	=> 'side',
	'priority' 	=> 'low',
	'local_images' => true,
	'fields' 	=> array(	
		// Show sidebar position on post page
		array(
			'name'    		=> esc_html__('Sidebar Position:', 'caliber'),
			'id'      		=> "{$prefix}position",
			'type'    		=> 'radio',
			'std'			=> 'left',
			'options'		=> array(
				'right'		=> 'Right',
				'left'		=> 'Left',
				'disabled'	=> 'Disabled',
			),
			'top_divider'	=> true
		),
	),
);
?>