<?php
/***************** Blog Posts ****************/
function shortcode_blog_posts_container($atts, $content = null) {
	$fc_blog_type = get_option('freshcodes_blog_type');
	$fc_blog_item = get_option('freshcodes_blog_items_per_column');
	$fc_blog_num_post = empty(get_option('freshcodes_blog_num_of_post')) ? get_option('freshcodes_blog_num_of_post') : '';
	$fc_blog_category_post = empty(get_option('freshcodes_blog_category')) ? get_option('freshcodes_blog_category') : '';
	$fc_blog_width = get_option('freshcodes_blog_width');
	$fc_blog_height = get_option('freshcodes_blog_height');
	$fc_blog_button = get_option('freshcodes_blog_button_text');
	$fc_blog_excerpt = get_option('freshcodes_blog_description_excerpt');
	extract(shortcode_atts(array(
		'type' => $fc_blog_type,
		'style' => '1',
		'items_per_column' => $fc_blog_item,
		'number_of_posts' => $fc_blog_num_post,
		'category' => $fc_blog_category_post,
		'width' => $fc_blog_width,
		'height' => $fc_blog_height,
		'linktext' => $fc_blog_button,
		'excerpt_length' => $fc_blog_excerpt

	), $atts));
	
	$linktextvariable = "";
	
if(!empty($category)):
	$term_id = $category;	
	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page' => $number_of_posts,
		'orderby' => 'date',
		'tax_query' => array(
			array(
				'taxonomy' => 'category',
				'field' => 'id',
				'terms' => $term_id
			)
		)
	);	
else:
	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
		'posts_per_page' => $number_of_posts,
		'orderby' => 'date'	
	);	
endif;	

$i = 1;
wp_reset_postdata();

$output = '';
$blog_array = new WP_Query( $args );	
$count = $blog_array->post_count;
$output = '';
if ( $blog_array->have_posts() ):
	$output .= '<div id="blog-posts-products" class="blog-posts-content posts-content '.$type.' style-'.$style.'">';	
	if($type == "slider") {
		if($count > $items_per_column)
			$output .= '<div id="'.$items_per_column.'_blog_carousel" class="slider blog-carousel">';
		else
			$output .= '<div id="blog_grid" class="blog-grid grid cols-'.$items_per_column.'">';
	} else {
		echo "grid";
		$output .= '<div id="blog_grid" class="blog-grid grid cols-'.$items_per_column.'">';
	}
	
	while ( $blog_array->have_posts() ) : $blog_array->the_post();

		if($i % $items_per_column == 1 )
			$class = " first";
		elseif($i % $items_per_column == 0 )
			$class = " last";
		else
		$class = "";
		$post_day = get_the_date('d');
		$post_month = get_the_date('F');
		$post_year = get_the_date('Y');
		$post_author = get_the_author();
        $comments = wp_count_comments(get_the_ID());
		$args = array(
			'status' => 'approved',
			'number' => '5',
			'post_id' => get_the_ID()
		);
		$comments = wp_count_comments(get_the_ID()); 				   
		if ( has_post_thumbnail() && ! post_password_required() ) :	
			$post_thumbnail_id = get_post_thumbnail_id();
		$image = wp_get_attachment_url( $post_thumbnail_id );
	else:
		$image = get_template_directory_uri()."/images/placeholders/placeholder.png";					
	endif;
	$src = $image;
// 	$src = freshcodes_mr_image_resize($image, $width, $height, true, 'c', false);
	if( empty ( $src ) || $src == 'image_not_specified' ):
		$src = get_template_directory_uri()."/images/freshcodes/placeholder.png";
// 		$src = freshcodes_mr_image_resize($src, $width, $height, true, 'c', false);			
	endif;

		$output .= '<div class="item container '.$class.'">';
		$output .= '<div class="container-inner">';

		$output .= '<div class="post-image-outer"><div class="post-image">';
		$output .= '<img src="'.$src.'" title="'.get_the_title().'" alt="'.get_the_title().'" />';
		$output .= '<div class="block_hover">';
		$output .= '<div class="links">';				
		$output .= '<a href="'.$image.'" class="icon mustang-gallery"></a>';				
		$output .= '<a href="'.get_permalink().'" class="icon attchment-icon"></a>';
		$output .= '</div>';
		$output .= '</div>';							
		$output .= '</div></div>';		
		$output .= '<div class="post-content-outer">';
		$output .= '<div class="entry-meta-blog">';
 		$output .= '</div>';
		$output .= '<div class="post-title"><h6 class="post-heading"><a href="'.get_permalink().'" title="'.get_the_title().'">'.get_the_title().'</a></h6></div>';	
		if ($excerpt_length > 0){ 
			$output .= '<div class="post-description">'.freshcodes_blog_post_excerpt($excerpt_length).'</div>';
		}
		$output .= '<div class="fc-date-btn-main">';
		if(!empty($linktext)):
			$output .= '<span class="read-more"><a class="button" href="'.get_permalink().'">'.$linktext.'</a></span>';
		endif;
		$output .= '<span class="entry-date"><span class="day-year"></span>'.$post_day.' '.$post_month.' '.$post_year.'</span></span>';
		$output .= '</div>';
	    $output .= '</div>';
		
		$output .= '</div></div>';

	$i++;
endwhile;
$output .= $linktextvariable;
wp_reset_postdata();
$output .=	'</div></div>';
else:
	$output .= '<div class="no-result">'.esc_html__('No results found...', 'calibre').'</div>';
endif;
return $output;
}
add_shortcode('freshcodes_blog_posts', 'shortcode_blog_posts_container');

	
/*************** Woo Category Slider & Grid **************/
function shortcode_woo_product_categories($atts, $content = null) {
	$fc_woocategory_type = get_option('freshcodes_wooo_category_type');
	$fc_woocategory_item = get_option('freshcodes_woo_category_items_per_column');
	$fc_woocategory_num_post = get_option('freshcodes_woo_category_num_of_post');
	$fc_woocategory_child_category = get_option('freshcodes_woo_category_child_category');
	$fc_woocategory_button_text = get_option('freshcodes_woo_category_button_text');
	$fc_woocategory_hide_empty = get_option('freshcodes_woo_category_hide_empty');
	$fc_woocategory_button_linktext_target = get_option('freshcodes_woo_category_linktext_target');
	$fc_woocategory_show_count = get_option('freshcodes_woo_category_show_count');
	$fc_woocategory_category_description_excerpt = get_option('freshcodes_woo_category_description_excerpt');

	extract(shortcode_atts(array(
			'type' => $fc_woocategory_type,
			'style' => '1',
			'items_per_column' => $fc_woocategory_item,
			'items_per_page' => $fc_woocategory_num_post,
			'height' => '366',
			'width' => '366',
			'child_category' => $fc_woocategory_child_category,
			'hide_empty' => $fc_woocategory_hide_empty,
			'target' => $fc_woocategory_button_linktext_target,
			'link_text' => $fc_woocategory_button_text,
			'count_display' => $fc_woocategory_show_count,
		), $atts));
	$category_ids_array = explode(",",'product_cat');	
	$output = '';
		$name='';
		$category_link_text='';		
		if($link_text !== ""){
			$category_link_text= '<span class="cat-all-category"><a class="button cat_name" target="'.$target.'" href="'.$link_text.'">'.esc_html__('View All', 'kartwow').'</a></span>';
		}
		$readmore='';
		if($type == "slider"){
			$output .= '<div class="woo_categories_slider woo_categories_block">';
			$output .= '<div id="'.$items_per_column.'_category_carousel" class="category-carousel">';
		}
		else{
			$output .= '<div class="woo_categories_grid woo_categories_block">';
			$output .= '<div id="'.$items_per_column.'_category_grid" class="fc-woo-category-grid columns-'.$items_per_column.'">';
		}
		$args = array(
			'parent'        => $child_category,
			'hide_empty'    => $hide_empty,
			'taxonomy'      => 'product_cat',
			'number'        => $items_per_page,
		);
		$categories = get_categories( $args );
		foreach($categories as $cat){	
			$category_ids = get_term( $cat, 'product_cat' );
			$thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
				if( empty ($thumbnail_id)):
					$src = get_template_directory_uri()."/images/freshcodes/placeholder.png";		
				else:
					$image = wp_get_attachment_url( $thumbnail_id );
					// $src = freshcodes_mr_image_resize($image, $width, $height, true, 't', false);
					$src = $image;
				endif;
									
			$output .= '<div class="cat-outer-block style-'.$style.'">';
			$output .= '<div class="cat-inner-block">';
			$output .= '<div class="cat-img-block">';
			$output .= '<a class="cat-img" target="'.$target.'" href="'.get_category_link( $category_ids ).'" title="'.$cat->name.'" >';
			$output .= '<img src="'.$src.'" title="'.$cat->name.'" alt="'.$cat->name.'"  height="'.$height.'" width="'.$width.'"/>';
			$output .= '</a>';
			$output .= '</div>';	
			$output .= '<div class="cat_description">';			
			$output .= '<a class="cat_name" target="'.$target.'" href="'.get_category_link( $category_ids ).'"  title="'.$cat->name.'"><h3 class="fc-cat-text">'.$cat->name.'</h3></a>';
			if($count_display == "yes"):
				$output .= '<span class="cat-count">('.$cat->count.' '.esc_html__('Items').')</span>';	
			endif;
			$output .= '</div>';			
			$output .= '</div>';
			$output .= '</div>';
		}	
	$output .= '</div>';
	$output .= $category_link_text;
	$output .= '</div>';	
	return $output;
	}
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) :
	add_shortcode("woo_product_categories", "shortcode_woo_product_categories");
	endif;
	 

/***************** Category wise products ****************/
function shortcode_woo_category_tab_products($atts, $content = null) {
	global $logotype;
	extract(shortcode_atts(array(
		'category' => '',
		'items_per_column' => 4,
		'width' => '',
		'height' => '',
		'columns' => '6',
		'limit' => '12',
		'display_all' => 'no',
		'child_category' => '',
		'hide_empty' => '1',
	), $atts));
	$category_ids_array = explode(",",$category);
	$category_ids_array[] = $category_ids_array;
	$categories = get_categories('hide_empty=0&orderby=name&taxonomy=product_cat');
	$output = '';
	$output .= '<div class="clearfix product-filter-container filter-container">';
	$output .= '<section id="product_filter_options" class="options category-container">';
	$output .= '<ul id="filters" class="option-set"  data-option-key="filter">';
 
	foreach ($categories as $category_item ) {
		$output .= '<li><a href="#'.$category.'" data-option-value=".'.$category_item->slug.'">'.$category_item->slug.'</a></li>';
	}
	$output .= '</ul></section>'; 		 
	$output .= '<div id="product_filter" class="product-container product-filter clearfix da-thumbs columns-'.$columns.'">';
	foreach ($categories as $category_item ): 
		$output .= '<div class="'.$category_item->slug.' main item single-product">';
		$output .= do_shortcode('[products category="'.$category_item->slug.'"  columns="'.$columns.'" limit="'.$limit.'"]');	
		$output .= '</div>';
	endforeach;
	wp_reset_query();
	$output .= '</div>'; 
	return $output;
}
add_shortcode('freshcodes_woo_category_tab_products', 'shortcode_woo_category_tab_products');


function fc_shortcode_woo_category_slider($atts, $content = null) {
	extract(shortcode_atts(array(
		'category_ids' => '',
		'items_per_column' => '3',
		'items_per_page' => '6',
		'type' => 'grid',
		'catlist' => '3',
		'class' => 'theme-container',
	), $atts));	
	$logotype = $type;	
	static  $cnt = 1;
	$output = '';	
	$category_ids_array = explode(",",$category_ids);
		$output = '';
	if (class_exists( 'WooCommerce' )) {
	$output .= '<div id="categorytab">';
		$category_ids = '';
		$term_category_id = '';
		$term_category_name = '';
		$term_categroy_slug = '';
		$term_thumbnai_id = '';
		$term_image = '';	
		$output .= '<div class="resp-tabs-title">';		
		$output .= '<ul id="'.$catlist.'_catlist_carousel"  class="resp-tabs-list catlist-carousel catlist-'.$catlist.' cols-'.$items_per_column.' '.$class.'">';			
		foreach($category_ids_array as $key){
				$category_ids = get_term( $key, 'product_cat' );
				if($category_ids){
					$term_category_id = $category_ids->term_id;
					$term_category_name = $category_ids->name;
					$term_category_slug = $category_ids->slug;
					$term_thumbnail_id =  get_term_meta( $term_category_id , 'thumbnail_id', true );		
					$term_image = wp_get_attachment_url( $term_thumbnail_id );  // get the image URL
					$output .= '<li><img src="'.$term_image.'" title="'.get_the_title().'" alt="'.get_the_title().'"/><div class="tab-title">'.$term_category_name.'</div></li>';
				}
			}
		$output .= '</ul>';
		$output .= '</div>';
		$output .= '<div class="'.$class.'">';
		$output .= '<div class="resp-tabs-container '.$type.'">';
			foreach($category_ids_array as $key){
					$term_array = get_term( $key, 'product_cat' );
				   	$term_category_id = isset($term_array->term_id) ? $term_array->term_id : '';
					$term_category_slug = isset($term_array->slug) ? $term_array->slug : '';
					$output .= do_shortcode('[woo_products type="'.$type.'" items_per_column="'.$items_per_column.'"][product_category  per_page="'.$items_per_page.'" Columns="'.$items_per_column.'" category="'.$term_category_slug.'"][/woo_products]');
			}
		$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';
	}
	return $output;
}
add_shortcode('woo_categories', 'fc_shortcode_woo_category_slider');

/*********** in stock product ***************/
function freshcodes_in_stock_products_shortcode() {
    
   $args = array(
      'post_type' => 'product',
      'posts_per_page' => -1,
      'post_status' => 'publish',
      'meta_query' => array(
         array(
            'key' => '_stock_status',
            'value' => 'instock',
         )
      ),
      'fields' => 'ids',
   );
 
   $product_ids = get_posts( $args ); 
   $product_ids = implode( ",", $product_ids );
 
   return do_shortcode("[products ids='$product_ids']");
  
}
add_shortcode( 'woo_in_stock_products', 'freshcodes_in_stock_products_shortcode' );
/**************** ----------- ******************/

	/***************** Portfolio Filter ****************/
	function shortcode_portfolio_filter_container($atts, $content = null) {
		global $logotype;
		extract(shortcode_atts(array(
			'items_per_column' => 4,
			'align' => '',
			'width' => '',
			'height' => ''		
		), $atts));
		$categories = get_categories('hide_empty=0&orderby=name&taxonomy=portfolio_categories');	
		$output = '';
		$output .= '<div class="clearfix portfolio-filter-container filter-container">';
		$output .= '<section id="portfolio_filter_options" class="options category-container">';
		$output .= '<ul id="filters" class="option-set"  data-option-key="filter">';
		$output .= '<li><a href="#show-all" data-option-value="*" class="selected">Show All</a></li>';
		foreach ($categories as $category_item ) {
			$output .= '<li><a href="#'.$category_item->slug.'" data-option-value=".'.$category_item->slug.'">'.$category_item->cat_name.'</a></li>';
		}
		$output .= '</ul></section>'; 
		$output .= '<div class="portfolio-filter-outer portfolios">';					 
		$output .= '<div id="portfolio_filter" class="portfolio-container portfolio-filter clearfix da-thumbs portfolio-cols-'.$items_per_column.'">';
		foreach ($categories as $category_item ):
			$paged = ( isset( $my_query_array['paged'] ) && !empty( $my_query_array['paged'] ) ) ? $my_query_array['paged'] : 1;
			$args = array(
				'post_type' => 'portfolio',
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'tax_query' => array(
					array(
						'taxonomy' => 'portfolio_categories',
						'field' => 'id',
						'terms' => $category_item->term_id,
						'paged' => $paged
					)
				)
			);
			query_posts($args);  
			while (have_posts()) : the_post();
				$image = freshcodes_get_first_post_images(get_the_ID());
				$src = freshcodes_mr_image_resize($image, $width, $height, true, 'c', false);
				if( empty ( $src ) || $src == 'image_not_specified' ):
					$src = get_template_directory_uri()."/images/freshcodes/placeholder.png";
					$src = freshcodes_mr_image_resize($src, $width, $height, true, false);
				endif;
				$output .= '<div class="'.$category_item->slug.' main item single-portfolio">';
				$output .= '<div class="image image-block">';
				$output .= '<img src="'.$src.'" title="'.get_the_title().'" alt="'.get_the_title().'"/>';
				$output .= '<div class="block_hover"><div class="block_hover_inner">';
				$output .= '<h3 class="entry-title">'.get_the_title().'</h3>';
				$output .= '<div class="links">';
				$output .= '<a href="'.$image.'" class="icon mustang-gallery"><i class="fa fa-plus"></i></a>';
				$output .= '<a href="'.get_permalink().'" class="icon"><i class="fa fa-link"></i></a>';
				$output .= '</div>';
				$output .= '</div>';
				$output .= '</div></div>';		
				$output .= '</div>';
			endwhile; 
		endforeach;
		wp_reset_query();
		$output .= '</div></div></div>'; 
		return $output;
	}
	add_shortcode('freshcodes_portfolio_filter', 'shortcode_portfolio_filter_container');

	/***************** Portfolio Slider ****************/
	function shortcode_portfolio_slider_container($atts, $content = null) {
		global $logotype;
		extract(shortcode_atts(array(
			'category' => '',
			'items_per_column' => 3,
			'number_of_posts' => 10,
			'width' => '',
			'height' => '',
			'excerpt_length' => '100'
		), $atts));

		if(!empty($category)):
			$term_id = $category;	
			$args = array(
				'post_type' => 'portfolio',
				'post_status' => 'publish',
				'posts_per_page' => $number_of_posts,
				'tax_query' => array(
					array(
						'taxonomy' => 'portfolio_categories',
						'field' => 'id',
						'terms' => $term_id
					)
				)
			);		
		else:
			$args = array(
				'post_type' => 'portfolio',
				'post_status' => 'publish',
				'posts_per_page' => "'".$number_of_posts."'"
			);		
		endif;			
		$array_posts = query_posts($args);
		$count = count($array_posts);
		$output = '';
		if($count > 0):
			$output .= '<div class="portfolio-container">';
			$output .= '<div id="'.$items_per_column.'_portfolio_carousel" class="portfolio-carousel  cols-'.$items_per_column.'">';
			$i = 1;
			while (have_posts()) : the_post();
				if($i % $items_per_column == 1 )
					$class = "first";
				elseif($i % $items_per_column == 0 )
					$class = "last";
				else
					$class = "";

				$image = freshcodes_get_first_post_images(get_the_ID());
				$image_src = freshcodes_mr_image_resize($image, $width, $height, true, 'c', false);
				if(empty($image_src))
					$image_src = get_template_directory_uri()."/images/freshcodes/placeholder.png";
				$output .= '<div class="item portfolio-main">';
				$output .= '<div class="product-block single-portfolio '.$class.'">';
				$output .= '<div class="portfolio-image">';
				$output .= '<img src="'.$image_src.'" title="'.get_the_title().'" alt="'.get_the_title().'"/>';
				$output .= '<div class="block_hover">';
				$output .= '<div class="links">';
				$output .= '<a href="'.$image.'" title="Click to view Full Image" class="icon mustang-gallery"><i class="fa fa-plus"></i></a>';
				$output .= '<a href="'.get_permalink().'" title="'.esc_html__('Click to view read more', 'calibre').'" class="icon"><i class="fa fa-link"></i></a>';							
				$output .= '</div>';
				$output .= '</div>';
				$output .= '</div>';
				$output .= '<div class="portfolio-title"><a href="'.get_permalink().'">'.get_the_title().'</a></div>';
				if ($excerpt_length > 0){ 
				$output .= '<div class="portfolio-description">'.freshcodes_portfolio_excerpt($excerpt_length	).'</div>';	
				}
				$output .= '<div class="read-more"><a href="'.get_permalink().'" title="'.get_the_title().'">'.esc_html__('Read more', 'calibre').'</a></div>';				
				$output .= '</div>';
				$output .= '</div>';
				$i++;
			endwhile;
			$output .= '</div>';
			wp_reset_query();
			$output .= '</div>';
		else:
			$output .= '<div class="no-result">'.esc_html__(''.esc_html__('No results found...', 'calibre').'', 'calibre').'</div>';
		endif;
		return $output;
	}
	add_shortcode('freshcodes_portfolio_slider', 'shortcode_portfolio_slider_container');

	/***************** Portfolio Grid  ****************/
	function shortcode_portfolio($atts, $content = null) {
		extract(shortcode_atts(array(
			'column' => 4,
			'cat' => '',
			'max' => '12',
			'width' => '',
			'height' => '',
			'excerpt_length' => '100'
		), $atts));

		$output = '';
		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		$terms = array();
		if ($cat != '') {
			$cat = preg_replace('/\s*,\s*/', ',', $cat);
			foreach(explode(',', $cat) as $term_name) {
				$terms[] = get_term_by('name', $term_name, 'portfolio_categories');
			}	
			foreach($terms as $term) {	
				$term_ids[] = $term->term_id;
			}	
			$args = array(
				'posts_per_page' => $max,
				'paged' => $paged,
				'post_type' => 'portfolio',
				'post_status' => 'publish',
				'tax_query' => array(
					array(
						'taxonomy' => 'portfolio_categories',
						'field' => 'id',
						'terms' => $term_ids
					)
				)
			);	
		} else {
			$args = array(
				'posts_per_page' => $max,
				'paged' => $paged,
				'post_type' => 'portfolio',
				'post_status' => 'publish'
			);
		}
		query_posts($args);
		$output = '<div class="portfolios">';
		$output .= '<ul class="portfolio_'.$column.'column da-thumbs">';
		$num_layout =  substr($column, 0, 1);	
		$i = 1;
		while(have_posts()) {
			the_post();
			$terms = get_the_terms(get_the_ID(), 'portfolio_categories');
			if ( strlen( $img = get_the_post_thumbnail( get_the_ID()) ) ): 
				$image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );	
			else:
				$image = freshcodes_get_first_post_images(get_the_ID());
			endif;
			$src = $image;
			if( empty ( $src ) || $src == 'image_not_specified' ):
				$src = get_template_directory_uri()."/images/freshcodes/placeholder.png";
				$image = $src;
				$src = $image;	
			endif;
			?>
			<?php $terms_slug = array();
			if (is_array($terms)) {
				foreach($terms as $term) {
					$terms_slug[] = $term->slug;
				}
			}
			if($i % $num_layout == 0)
				$li_class = "last";
			else if($i % $num_layout == 1)
				$li_class = "first";
			else
				$li_class = "inner";
			$output .= '<li class="'.$li_class.'">';
			$more = get_post_meta(get_the_ID(), '_more', true);
			$output .= '<div class="main"><div class="image-block">';
			if(get_option('portfolio','display_image') || $column == 1):	
				$output .= '<a href= "'.$image.'" class="mustang-gallery">';
				$output .= '<img class="image1" src="'.$src.'" alt="'.get_the_title().'" />';
				$output .= '</a>';
			endif;
			$output .= '<div class="block_hover">';
			$output .= '<div class="links">';
			$output .= '<a href="'.$image.'" title="Click to view Full Image" class="icon mustang-gallery"><i class="fa fa-plus"></i></a>';
			$output .= '<a href="'.get_permalink().'"  title="'.esc_html__('Click to view read more', 'calibre').'" class="icon"><i class="fa fa-link"></i></a>';
			$output .= '</div></div>';
			$output .= '</div>';
			$output .= '<a class="portfolio-title" href="'.get_permalink().'"><h4>'.get_the_title().'</h4></a>';
			if ($excerpt_length > 0){ 
			$output .=  freshcodes_excerpt_length_limit($excerpt_length);
			}
			$output .= '</div></li>';
			$i++;
		}
		$output .= '</ul>';
		$output .= freshcodes_shortcode_paging_nav();  
		$output .= '</div>';	  
		wp_reset_query();
		return $output;
	}
	add_shortcode('freshcodes_portfolio', 'shortcode_portfolio');

	/***************** Products ****************/
	function shortcode_woo_products_container($atts, $content = null) {
		global $logotype;
		extract(shortcode_atts(array(
			'type' => 'slider',
			'items_per_column' => 5,
			'product' => 'shop',
			'classname' => '',
			'no_more'  => 'No more Products to display'	
		), $atts));
		$logotype = $type;	
		static  $cnt = 1;
		$output = '';	
		
		$output .= '<div class="woo-products woo-content products_block '.$product.' '.$classname.'">';
		if($type == "slider") { 
			$output .= '<div id="'.$items_per_column.'_woo_carousel" class="woo-carousel cols-'.$items_per_column.'">';
		}
		elseif($type == "list") { 
			$output .= '<div class="woo_list woo-list cols-'.$items_per_column.'">';
		}
		else {
			$output .= '<div class="woo_grid woo-grid cols-'.$items_per_column.'">';
		}
		$output .= do_shortcode($content).'</div>';
		if($type == "grid") {  
			$output .=	'<div class="freshcodes-message"><i class="fa fa-frown-o"></i>'.$no_more.'</div>';
			$output .=	'<div class="loadgridlist-wrapper"><button class="woocount loadgridlist">'.esc_html__('View More Products', 'calibre').'</button></div>';		
		}
		$output .='</div>';
		$cnt++;
		return $output;
	}
	add_shortcode('woo_products', 'shortcode_woo_products_container');

		/***************** Our Team ****************/
		function shortcode_ourteam($atts, $content = null) {
			$freshcodes_staff_type = get_option('freshcodes_staff_type');
			$freshcodes_staff_items_per_column = get_option('freshcodes_staff_items_per_column');
			$freshcodes_staff_num_of_post = get_option('freshcodes_staff_num_of_post');
			extract(shortcode_atts(array(
				'type' => $freshcodes_staff_type,
				'items_per_column' => $freshcodes_staff_items_per_column,
				'image_width' => 600,
				'image_height' => 600,
				'number_of_posts' => $freshcodes_staff_num_of_post
			), $atts));

			global $post;	
			$i = 1;
			$output = '';
			wp_reset_postdata();
			$args = array(
				'posts_per_page' => $number_of_posts,
				'post_status' => 'publish',
				'post_type' => 'staff',
				'orderby' => 'date'
			);		

			$output = '';
			$team_array = new WP_Query( $args );

			if ( $team_array->have_posts() ):
				$output .= '<div id="team-posts-products" class="team-posts-content staff-page posts-content">';	
				if($type == "slider") { 
					$output .= '<div id="'.$items_per_column.'_team_carousel" class="team-carousel">';
				} else {
					$output .= '<div id="team_grid" class="team-grid grid cols-'.$items_per_column.'">';
				}	
				while ( $team_array->have_posts() ) : $team_array->the_post();
					get_post_meta(get_the_ID(), 'staff_position', TRUE) ? $staff_position = get_post_meta(get_the_ID(), 'staff_position', TRUE) : $staff_position = '';
					get_post_meta(get_the_ID(), 'staff_link', TRUE) ? $staff_link = get_post_meta(get_the_ID(), 'staff_link', TRUE) : $staff_link = '';
					get_post_meta(get_the_ID(), 'staff_phone', TRUE) ? $staff_phone = get_post_meta(get_the_ID(), 'staff_phone', TRUE) : $staff_phone = '';
					get_post_meta(get_the_ID(), 'staff_email', TRUE) ? $staff_email = get_post_meta(get_the_ID(), 'staff_email', TRUE) : $staff_email = '';
					get_post_meta(get_the_ID(), 'staff_twitter', TRUE) ? $staff_twitter = get_post_meta(get_the_ID(), 'staff_twitter', TRUE) : $staff_twitter = '';
					get_post_meta(get_the_ID(), 'staff_facebook', TRUE) ? $staff_facebook = get_post_meta(get_the_ID(), 'staff_facebook', TRUE) : $staff_facebook = '';
					get_post_meta(get_the_ID(), 'staff_google_plus', TRUE) ? $staff_google_plus = get_post_meta(get_the_ID(), 'staff_google_plus', TRUE) : $staff_google_plus = '';
					get_post_meta(get_the_ID(), 'staff_linkedin', TRUE) ? $staff_linkedin = get_post_meta(get_the_ID(), 'staff_linkedin', TRUE) : $staff_linkedin = '';
					get_post_meta(get_the_ID(), 'staff_youtube', TRUE) ? $staff_youtube = get_post_meta(get_the_ID(), 'staff_youtube', TRUE) : $staff_youtube = '';
					get_post_meta(get_the_ID(), 'staff_rss', TRUE) ? $staff_rss = get_post_meta(get_the_ID(), 'staff_rss', TRUE) : $staff_rss = '';
					get_post_meta(get_the_ID(), 'staff_pinterest', TRUE) ? $staff_pinterest = get_post_meta(get_the_ID(), 'staff_pinterest', TRUE) : $staff_pinterest = '';
					get_post_meta(get_the_ID(), 'staff_skype', TRUE) ? $staff_skype = get_post_meta(get_the_ID(), 'staff_skype', TRUE) : $staff_skype = ''; 
					$s = 0; 
					if(!empty($staff_link)) $s++;
					if(!empty($staff_email)) $s++; 
					if(!empty($staff_twitter)) $s++; 
					if(!empty($staff_facebook)) $s++; 
					if(!empty($staff_google_plus)) $s++; 
					if(!empty($staff_linkedin)) $s++; 
					if(!empty($staff_youtube)) $s++; 
					if(!empty($staff_rss)) $s++; 
					if(!empty($staff_pinterest)) $s++; 
					if(!empty($staff_skype)) $s++;	
					if($i % $items_per_column == 1 )
						$class = " first";
					elseif($i % $items_per_column == 0 )
						$class = " last";
					else
						$class = "";
					if ( has_post_thumbnail() && ! post_password_required() ) :	
						$post_thumbnail_id = get_post_thumbnail_id();
					$image = wp_get_attachment_url( $post_thumbnail_id );
				else:
					$image = get_template_directory_uri()."/images/placeholders/placeholder.png";
				endif;
				$src = $image;
				if( empty ( $src ) || $src == 'image_not_specified' ):
					$src = get_template_directory_uri()."/images/freshcodes/placeholder.png";
					$src = $src;
				endif;
				$output .= '<article class="item container'.$class.'">';
				$output .= '<div class="single-team container-inner">';
				$output .= '<div class="staff-image">';
				$output .= '<img src="'.$src.'" title="'.get_the_title().'" alt="'.get_the_title().'" />';
				$output .= '<div class="staff-image-hover"></div>';
				$output .= '</div>';	
				$output .= '<div class="team-info">';	
				$output .= '<div class="staff-content">';	
				$shorttitle = substr(the_title('','',FALSE),0,150);
				if(!empty($shorttitle) && $shorttitle != '')
					$output .= '<div class="staff-name"><a title="'.get_the_title().'" href="'.get_permalink().'" >'.$shorttitle.'</a></div>';
				if(!empty($staff_position) && $staff_position != '')
					$output .= '<div class="staff-position">(<span>'.$staff_position.'</span>)</div>';
				$content = substr(get_the_content('','',FALSE),0,70);
				$output .= '<div class="staff_content">'.$content.'</div>';

				$output .= '<div class="staff-social icon-'.$s.'">';			
				if(!empty($staff_link) && $staff_link != '')
					$output .= '<a href="'.$staff_link.'" title="Website" class="website icon"><i class="fa fa-link"></i></a>';
				if(!empty($staff_email) && $staff_email != '')
					$output .= '<a href="mailto:'.$staff_email.'" title="Email" class="email icon"><i class="fa fa-envelope-o"></i></a>';
				if(!empty($staff_twitter) && $staff_twitter != '')
					$output .= '<a href="'.$staff_twitter.'" title="Twitter" class="twitter icon"><i class="fa fa-twitter"></i></a>';
				if(!empty($staff_facebook) && $staff_facebook != '')
					$output .= '<a href="'.$staff_facebook.'" title="Facebook" class="facebook icon"><i class="fa fa-facebook"></i></a>';
				if(!empty($staff_google_plus) && $staff_google_plus != '')
					$output .= '<a href="'.$staff_google_plus.'" title="Google Plus" class="google-plus icon"><i class="fa fa-google-plus"></i></a>';
				if(!empty($staff_linkedin) && $staff_linkedin != '')
					$output .= '<a href="'.$staff_linkedin.'" title="Linkedin" class="linkedin icon"><i class="fa fa-linkedin"></i></a>';
				if(!empty($staff_youtube) && $staff_youtube != '')
					$output .= '<a href="'.$staff_youtube.'" title="Youtube" class="youtube icon"><i class="fa fa-youtube"></i></a>';
				if(!empty($staff_rss) && $staff_rss != '')
					$output .= '<a href="'.$staff_rss.'" title="RSS" class="rss icon"><i class="fa fa-rss"></i></a>';
				if(!empty($staff_pinterest) && $staff_pinterest != '')
					$output .= '<a href="'.$staff_pinterest.'" title="Pinterest" class="pinterest icon"><i class="fa fa-pinterest"></i></a>';
				if(!empty($staff_skype) && $staff_skype != '')
					$output .= '<a href="'.$staff_skype.'" title="Skype" class="skype icon"><i class="fa fa-skype"></i></a>';
				$output .= '</div>';			
				$output .= '</div>';
				$output .= '</div>';
				$output .= '</div></article>';
				$i++;
			endwhile;
			wp_reset_postdata();
			$output .=	'</div></div>';
		else:
			$output .= '<div class="no-result">'.esc_html__('No results found...', 'calibre').'</div>';
		endif;
		return $output;
	}
	add_shortcode("freshcodes_ourteam", "shortcode_ourteam");
	/***************** Custom Testimonial ****************/
	function shortcode_custom_testimonials($atts, $content = null) {
		$freshcodes_testimonial_type = get_option('freshcodes_testimonial_type');
		$freshcodes_testimonial_items_per_column = get_option('freshcodes_testimonial_items_per_column');
		$freshcodes_testimonial_num_of_post = get_option('freshcodes_testimonial_num_of_post');
		$freshcodes_testimonial_excerpt = get_option('freshcodes_testimonial_excerpt');
		extract(shortcode_atts(array(
			'type' => $freshcodes_testimonial_type,
			'items_per_column' => $freshcodes_testimonial_items_per_column,
			'number_of_posts' => $freshcodes_testimonial_num_of_post,		
			'image_width' => 50,
			'image_height' => 50,
			'excerpt_length' => $freshcodes_testimonial_excerpt
		), $atts));


		global $post;	
		$i = 1;
		$args = array(
			'posts_per_page' => $number_of_posts,
			'post_status' => 'publish',
			'post_type' => 'testimonial',
		);					
		$testimonial_array = get_posts($args);
		$testimonial_count = count($testimonial_array);
		$output = '';
		if($testimonial_count > 0 ):
			$output .= '<div class="custom-testimonial '.$type.'">';		
			if($type == "slider") { 
				$output .= '<div id="'.$items_per_column.'_testimonial_carousel" class="testimonial-carousel">';
			} elseif($type == "grid") {
				$output .= '<div id="testimonial_grid" class="testimonial-grid testimonial-cols-'.$items_per_column.'">';
			} 
			$i = 1;
			$temp2 = 0;
			foreach($testimonial_array as $post) : setup_postdata($post);	
				get_post_meta($post->ID, 'testimonial_position', TRUE) ? $testimonial_position = get_post_meta($post->ID, 'testimonial_position', TRUE) : $testimonial_position = '';
				get_post_meta($post->ID, 'testimonial_link', TRUE) ? $testimonial_link = get_post_meta($post->ID, 'testimonial_link', TRUE) : $testimonial_link = '';		
				$contents = strip_tags(freshcodes_strip_images($post->post_content));
				if($i % $items_per_column == 1)
					$class = " first-item";	
				elseif($i % $items_per_column == 0)
					$class = " last-item";
				else
					$class = "";
				$output .= '<div class="item'.$class.'">';					
				$output .= '<div class="product-block">';
				$output .= '<div class="custom-testimonial-inner">';											

				$output .= '<div class="testmonial-image">';
				if ( has_post_thumbnail() && ! post_password_required() ) :
					$post_thumbnail_id = get_post_thumbnail_id();
					$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
					$output .= '<img src="'.$post_thumbnail_url.'" title="'.get_the_title().'" alt="'.get_the_title().'" />';
				else:
					$output .= '<i style="width:'.$image_width.';height:'.$image_height.';" class="fa fa-user"></i>';
				endif;
				$output .= '</div>';
				
				$output .= '<div class="testimonial-wrapper">';
				if ($excerpt_length > 0){ 
				$output .=  '<div class="testimonial-content"><h6 class="fc-testimonial-content">'.freshcodes_excerpt_length_limit($excerpt_length).'</h6></div>';
				}
				$output .= '<div class="testmonial-text">';			
				$output .= '<div class="testimonial-title"><h5 class="fc-testimonial-title"><a title="'.get_the_title().'" href="'.get_permalink().'" >'.get_the_title().'</a></h5></div>';
				if(!empty($testimonial_position)):
						$output .= '<div class="testimonial-designation">'.$testimonial_position.'</div>';	
				endif;
				$output .= '</div>';
				$output .= '</div>';

			$output .= '</div>';
				$output .= '</div>';
			
				$output .= '</div>';

				$i++;
			endforeach;
			$output .= '</div>';
			$output .= '</div>';
		else:
			$output .= '<div class="no-result">'.esc_html__('No results found...', 'calibre').'</div>';
		endif;
		wp_reset_query();
		return $output;
	}
	add_shortcode('fc_custom_testimonials', 'shortcode_custom_testimonials');


	/********************* Hot products Grid/slider ***************/ 
function shortcode_hot_products($atts, $content = null)
{
	$freshcodes_woo_hot_type = get_option('freshcodes_woo_hot_type');
	$freshcodes_woo_hot_items_per_column = get_option('freshcodes_woo_hot_items_per_column');
	$freshcodes_woo_hot_num_of_post = get_option('freshcodes_woo_hot_num_of_post');
	$freshcodes_woo_hot_custom_class = get_option('freshcodes_woo_hot_custom_class');
	$fc_countdown_text = get_option('fc_countdown_text');

	extract(shortcode_atts(array(
		'type' => $freshcodes_woo_hot_type,
		'items_per_column' => $freshcodes_woo_hot_items_per_column,
		'items_per_page' => $freshcodes_woo_hot_num_of_post,
		'height' => '',
		'width' => '',
		'product' => 'shop',
		'fc_countdown_text' => $fc_countdown_text,
		'classname' => $freshcodes_woo_hot_custom_class,
	), $atts));
$output = '';
global $post;
global $product;
$freshcodes_excerpt_show = get_option("freshcodes_excerpt_show");
$params = array(
	'posts_per_page' => -1, 
	'post_type' => array('product', 'product_variation'));

$wc_query = new WP_Query($params);
if ( in_array( 'woocommerce/woocommerce.php' ,apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ){
$output .= '<div class="woo-products woo-content products_block '.$product.' '.$classname.'">';	
$output .= '<div id="'.$items_per_column.'_hot_product_carousel" class="woocommerce hot-product">';
if($type == "slider") 
	{
		$output .= '<ul class="products woo-slider">';
	} else {
		$output .= '<ul id="woo_grid" class="woo-grid">';
	}
      if ($wc_query->have_posts()) :
          while ($wc_query->have_posts()) :
                $wc_query->the_post(); 
    $today = date('Y-m-d');
	$sale_price_dates_from = ( $date = get_post_meta( $post->ID, '_sale_price_dates_from', true ) ) ? date_i18n( 'Y-m-d', $date ) : '';	
 	$sale_price_dates_to    = ( $date = get_post_meta( $post->ID, '_sale_price_dates_to', true ) ) ? date_i18n( 'Y-m-d', $date ) : '';
	if ($today >= $sale_price_dates_from  && $today <= $sale_price_dates_to){
	if ($sale_price_dates_to != "")
	{
		global $product;
		$rating = $product->get_average_rating();
		$id = $product->get_id();
		$product_cats = get_the_terms( $id, 'product_cat' );
		$attachment_ids = $product->get_gallery_image_ids();		
$output .= '<li class="product theme-container">';
	 $output .= '<div class="container-inner">';
		$output .= '<div class="product-block-inner">';
			$output .= '<div class="image-block">';	
			$placeholder_img = get_template_directory_uri()."/images/freshcodes/placeholder.png";
			$image_link    = wp_get_attachment_url( get_post_thumbnail_id() );
					if ( has_post_thumbnail() ) {
			  			$image_caption = get_post( get_post_thumbnail_id() )->post_excerpt;			  			
						$image         = get_the_post_thumbnail( $post->ID, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ), array(
							'title'	=> get_the_title( get_post_thumbnail_id() )
						) );	
						$output .= '<a href="'.get_permalink().'"><img alt="'.get_the_title().'" src="'.$image_link.'" height="'.$height.'"  width="'.$width.'"/></a>';
					}
				   	else{
						$output .= '<a href="'.get_permalink().'"><img href="'.get_permalink().'" alt="'.get_the_title().'" src="'.$placeholder_img.'" height="'.$height.'"  width="'.$width.'"/></a>';
					}
					
				
					$output .='<div class="product-button-hover"><div class="product-button-hover-inner">';
						if ( in_array( 'yith-woocommerce-quick-view/init.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ):
							$output .= do_shortcode( "[yith_quick_view]" );
						endif;
						if ( in_array( 'yith-woocommerce-wishlist/init.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ):
							$output .= do_shortcode( "[yith_wcwl_add_to_wishlist]" );
						endif;
						if ( in_array( 'yith-woocommerce-compare/init.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ):
							$output .= do_shortcode( "[yith_compare_button]" );
						endif;						
					$output .= '</div></div>';
				$output .='<div class="fc-sale-counter-main">';
				$output .='<div class="count-down product-count-down">';
				$output .='<div class="countbox-text">'.$fc_countdown_text.'</div>';
				$output .='<div class="countbox hastime" data-time="'.$sale_price_dates_to.'"></div>';
				$output .= '</div>';
				$output .='</div>';
				if($product->is_on_sale()) :
				$regular_price = $product->get_regular_price();
			   $sale_price = $product->get_sale_price();
			
			   if($regular_price != $sale_price && $regular_price != 0){
				   $discount = round(100-(($sale_price / $regular_price)*100));
				   $class = floor((($sale_price / $regular_price)*100)/10)*10;
			   }
			   $output.='<div class="fc-onsale-main">';
			   $output.='<span class="fc-onsale">';
			   $output.='<span class="fc-sale-tax">'.$discount.'%</span>';
			   $output.='</span>';
			   $output.='</div>';

			endif;
			$output .= '</div>';
								
			$output .='<div class="product-detail-wrapper">';
			if(get_option("freshcodes_stock_show") == "yes"):
// 				$output .='<div class="fc_product_status">'.do_action("woocommerce_freshcodes_product_status").'</div>';
			endif;
			$output .='<h6 class="product-name">';		
			$output .='<a href="'.get_permalink().'">'.$product->get_title().'</a>';
			$output .='</h6>';
			if($freshcodes_excerpt_show == 'yes'):
			$output .='<div class="fc-product-description"><span>' .freshcodes_woo_hot_product_excerpt(). '</span></div>';
			endif;
			$output .='<div class="fc-categroy">';
			$output .='<span class="fc-category-text"> Categories : ';
			foreach($product_cats as $product_cat){
				$output .='<span>' .$product_cat->name. '</span>';
			}
			$output .='</span>';
			$output .='</div>';
			$output .='<div class="price">'.$product->get_price_html().'</div>';
	if ( ! $product->is_in_stock() ) : 
    	$output .= '<a href="'.apply_filters( 'out_of_stock_add_to_cart_url', get_permalink( $product->get_id() ) ).'" class="button">'.apply_filters( 'out_of_stock_add_to_cart_text', __( 'Read More', 'woocommerce' ) ).'</a>';
 	else :
        $link = array(
            'url'   => '',
            'label' => '',
            'class' => ''
        );
		switch ( $product->get_type() ) {
			case "variable" :
				$link['url']    = apply_filters( 'variable_add_to_cart_url', get_permalink( $product->get_id() ) );
				$link['label']  = apply_filters( 'variable_add_to_cart_text', __( 'Select options', 'woocommerce' ) );
			break;
			case "grouped" :
				$link['url']    = apply_filters( 'grouped_add_to_cart_url', get_permalink( $product->get_id() ) );
				$link['label']  = apply_filters( 'grouped_add_to_cart_text', __( 'View options', 'woocommerce' ) );
			break;
			case "external" :
				$link['url']    = apply_filters( 'external_add_to_cart_url', get_permalink( $product->get_id() ) );
				$link['label']  = apply_filters( 'external_add_to_cart_text', __( 'Read More', 'woocommerce' ) );
			break;
			default :
				if ( $product->is_purchasable() ) {
					$link['url']    = apply_filters( 'add_to_cart_url', esc_url( $product->add_to_cart_url() ) );
					$link['label']  = apply_filters( 'add_to_cart_text', __( 'Add to cart', 'woocommerce' ) );
					$link['class']  = apply_filters( 'add_to_cart_class', 'add_to_cart_button' );
				} else {
					$link['url']    = apply_filters( 'not_purchasable_url', get_permalink( $product->get_id() ) );
					$link['label']  = apply_filters( 'not_purchasable_text', __( 'Read More', 'woocommerce' ) );
				}
			break;
		}
	endif;
	$output .= '</div>';
	$output .= '</div>';
	$output .='</div>';
	$output .= '</li>';
	} 
}
      endwhile; 
      wp_reset_postdata();
 endif;
$output .='</ul>';
$output .= '</div>';
$output .= '</div>';
}
return $output;

}
add_shortcode('freshcodes_hot_products', 'shortcode_hot_products');

//deactivate WordPress function
remove_shortcode('gallery', 'gallery_shortcode');

//activate Freshcodes own function
	add_shortcode('gallery', 'msdva_gallery_shortcode');
	function msdva_gallery_shortcode($attr) {
		$post = get_post();

		static $instance = 0;
		$instance++;

		if ( ! empty( $attr['ids'] ) ) {
// 'ids' is explicitly ordered, unless you specify otherwise.
			if ( empty( $attr['orderby'] ) )
				$attr['orderby'] = 'post__in';
			$attr['include'] = $attr['ids'];
		}

// Allow plugins/themes to override the default gallery template.
		$output = apply_filters('post_gallery', '', $attr);
		if ( $output != '' )
			return $output;

// We're trusting author input, so let's at least make sure it looks like a valid orderby statement
		if ( isset( $attr['orderby'] ) ) {
			$attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
			if ( !$attr['orderby'] )
				unset( $attr['orderby'] );
		}

		extract(shortcode_atts(array(
			'order' => 'ASC',
			'orderby' => 'menu_order ID',
			'id' => $post ? $post->ID : 0,
			'itemtag' => 'dl',
			'icontag' => 'dt',
			'captiontag' => 'dd',
			'divtag' => 'div',
			'columns' => 3,
			'size' => 'full',
			'include' => '',
			'exclude' => '',
			'link' => 'file' // CHANGE #1
), $attr, 'gallery'));

		$id = intval($id);
		if ( 'RAND' == $order )
			$orderby = 'none';

		if ( !empty($include) ) {
			$_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

			$attachments = array();
			foreach ( $_attachments as $key => $val ) {
				$attachments[$val->ID] = $_attachments[$key];
			}
		} elseif ( !empty($exclude) ) {
			$attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
		} else {
			$attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
		}
		if ( empty($attachments) )
			return '';

		if ( is_feed() ) {
			$output = "\n";
			foreach ( $attachments as $att_id => $attachment )
				$output .= freshcodes_wp_get_attachment_link($att_id, $size, true) . "\n";
			return $output;
		}
		$itemtag = tag_escape($itemtag);
		$captiontag = tag_escape($captiontag);
		$icontag = tag_escape($icontag);
		$valid_tags = wp_kses_allowed_html( 'post' );
		if ( ! isset( $valid_tags[ $itemtag ] ) )
			$itemtag = 'dl';
		if ( ! isset( $valid_tags[ $captiontag ] ) )
			$captiontag = 'dd';
		if ( ! isset( $valid_tags[ $icontag ] ) )
			$icontag = 'dt';

		$columns = intval($columns);
		$itemwidth = $columns > 0 ? floor(100/$columns) : 100;
		$float = is_rtl() ? 'right' : 'left';
		$selector = "gallery-{$instance}";

		$gallery_style = $gallery_div = '';
		if ( apply_filters( 'use_default_gallery_style', true ) )
			$gallery_style = "
		<style type='text/css'>
#{$selector} {
		margin: auto;
	}
#{$selector} .gallery-item {
	float: {$float};
	margin-top: 10px;
	text-align: center;
	width: {$itemwidth}%;
}
#{$selector} img {
border: 2px solid #cfcfcf;
}
#{$selector} .gallery-caption {
margin-left: 0;
}
/* see gallery_shortcode() in wp-includes/media.php */
</style>";
$size_class = sanitize_html_class( $size );
$gallery_div = "<div id='$selector' class='gallery galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class}'>";
$output = apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $gallery_div );

$i = 0;
foreach ( $attachments as $id => $attachment ) {
	$image_url = $attachment->guid;
	$image_output = freshcodes_wp_get_attachment_link( $id, $size, true, false );
	$image_meta = wp_get_attachment_metadata( $id );

	$orientation = '';
	if ( isset( $image_meta['height'], $image_meta['width'] ) )
		$orientation = ( $image_meta['height'] > $image_meta['width'] ) ? 'portrait' : 'landscape';
	$output .= "<{$itemtag} class='gallery-item'>";
	$output .= "
	<{$icontag} class='gallery-icon {$orientation}'>
	$image_output
	</{$icontag}>";
	$output .= "
	<{$captiontag} class='wp-caption-text gallery-caption'>
	<{$divtag} class='gallery-caption-inner'>";
	$output .= " <{$divtag} class='wp-caption-text gallery-title'>
	" . wptexturize($attachment->post_title) . "
	</{$divtag}>";
		if ( $captiontag && trim($attachment->post_excerpt) ) {		
		$output .= "<{$divtag} class='wp-caption-text gallery-excerpt'>";
		if($columns == 1):		
			$excerpt_length = 100;
		elseif($columns == 2):
			$excerpt_length = 300;
		elseif($columns == 3):
			$excerpt_length = 200;
		elseif($columns == 4):
			$excerpt_length = 50;
		elseif($columns == 5):
			$excerpt_length = 10;
		endif;
		$output .= substr($attachment->post_excerpt,0,$excerpt_length);		
		$output .= "</{$divtag}>";

		$output .= "<{$divtag} class='wp-caption-text 56566 gallery-zoom'>
		<a href=" . $image_url . " title='Click to view Full Image' class='icon mustang-gallery'><i class='fa fa-plus'></i></a>
		</{$divtag}>";

		$output .= "<{$divtag} class='wp-caption-text 56566 gallery-redirect'>
		<a href=" . get_attachment_link( $attachment->ID ) . " title='Click to view read more' class='icon readmore'><i class='fa fa-link'></i></a>
		</{$divtag}>"; 
	}else{
		$output .= "<{$divtag} class='wp-caption-text 56566 gallery-zoom no-text'>
		<a href=" . $image_url . " title='Click to view Full Image' class='icon mustang-gallery'><i class='fa fa-plus'></i></a>
		</{$divtag}>";		
		$output .= "<{$divtag} class='wp-caption-text 56566 gallery-redirect'>
		<a href=" . get_attachment_link( $attachment->ID ) . " title='Click to view read more' class='icon readmore'><i class='fa fa-link'></i></a>
		</{$divtag}>";
	}
	$output .= "</{$divtag}>";	
	$output .= "</{$captiontag}>";
	$output .= "</{$itemtag}>";
}

$output .= "
</div>\n";
return $output;
}

function freshcodes_wp_get_attachment_link( $id = 0, $size = 'thumbnail', $permalink = true, $icon = false, $text = false ) {
	$id = intval( $id );
	$_post = get_post( $id );
	if ( empty( $_post ) || ( 'attachment' != $_post->post_type ) || ! $url = wp_get_attachment_url( $_post->ID ) )
		return __( 'Missing Attachment', 'calibre' );
	if ( $permalink )
// FIX!! ask for large URL
		$image_attributes = wp_get_attachment_image_src( $_post->ID, 'large' );
	$url = $image_attributes[0];
	$post_title = esc_attr( $_post->post_title );

	if ( $text )
		$link_text = $text;
	elseif ( $size && 'none' != $size )
		$link_text = wp_get_attachment_image( $id, $size, $icon );
	else
		$link_text = '';

	if ( trim( $link_text ) == '' )
		$link_text = $_post->post_title; 
	return apply_filters( 'wp_get_attachment_link', "<a rel='gallery-nr'>$link_text</a>", $id, $size, $permalink, $icon, $text );
}


/********************* counter ***************/ 
function shortcode_counter($atts, $content = null)
{
	extract(shortcode_atts(array(
		'counter_date' => '2023-06-16'
	), $atts));

$output = '';
$output .='<div class="count-down product-count-down">';	
$output .='<div class="countbox hastime" data-time="'.$counter_date.'"></div>';	
$output .= '</div>';	
return $output;

}
add_shortcode('freshcodes_counter', 'shortcode_counter');
?>