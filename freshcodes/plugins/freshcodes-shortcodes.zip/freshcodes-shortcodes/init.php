<?php
/*
  Plugin Name: Freshcodes Shortcode
  Description: Freshcodes Custom Shortcodes for freshcodes wordpress themes.
  Version: 1.0
  Author: Freshcodes
 */
?>
<?php  if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly
if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
?>
<?php 
 // Before VC Init
if ( ! defined( 'FC_SHORTCODE_DIR' ) ) {
define( 'FC_SHORTCODE_DIR', plugin_dir_path( __FILE__ ) );  
}
if ( ! defined( 'FC_SHORTCODE_URL' ) ) {
	define( 'FC_SHORTCODE_URL', plugin_dir_url( __FILE__ ) );
}
    //.. Code from other Tutorials ..//
function freshcodes_shortcode_init()
{
    // Require new custom Element
    require_once( FC_SHORTCODE_DIR.'/shortcodes/freshcodes-shortcodes.php' );
}
add_action('freshcodes_shortcode_init', 'freshcodes_shortcode_init');
function freshcodes_shortcode_install() { 
	do_action( 'freshcodes_shortcode_init' );
}
add_action( 'plugins_loaded', 'freshcodes_shortcode_install', 11 );

if( ! function_exists( 'freshcodes_get_categories' ) ){
/**
 * GET Categories | Categories for posts or specified taxonomy
 *
 * @param string $category Category slug
 * @return array
 */
function freshcodes_get_categories( $category ) {
    $categories = get_categories( array( 'taxonomy' => $category ));
    $array = array( '' => __( 'All', 'freshcodes-opts' ) );
        foreach( $categories as $cat ){
        if( is_object($cat) ) $array[$cat->slug] = $cat->name;
        }
        return $array;
    }
}
/**
 * GET Product Categories | Product Categories for Products
 *
 * @param string $category Category slug
 * @return array
 */

if( ! function_exists( 'freshcodes_product_get_categories' ) ){
  function freshcodes_product_get_categories( $category ) {
     $taxonomy = 'product_cat';
        $orderby = 'name';
        $show_count = 0;      // 1 for yes, 0 for no
        $pad_counts = 0;      // 1 for yes, 0 for no
        $hierarchical = 1;    // 1 for yes, 0 for no
        $title = '';
        $empty = 0;
        
        $args = array(
            'taxonomy' => $taxonomy,
            'orderby' => $orderby,
            'show_count' => $show_count,
            'pad_counts' => $pad_counts,
            'hierarchical' => $hierarchical,
            'title_li' => $title,
            'hide_empty' => $empty
        );
     $categories = get_categories($args); 
     $array = array( '' => __( 'All', 'freshcodes-opts' ) );
        foreach( $categories as $cat ){
        if( is_object($cat) ) 
          $array[$cat->name] = $cat->slug;    
        }
        return $array;
    }
  }


function freshcodes_add_file_types_to_uploads($file_types){
	$new_filetypes = array();
	$new_filetypes['svg'] = 'image/svg+xml';
	$file_types = array_merge($file_types, $new_filetypes );
	return $file_types;
	}
add_filter('upload_mimes', 'freshcodes_add_file_types_to_uploads');
?>