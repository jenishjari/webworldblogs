<?php 
/*
  Plugin Name: Freshcodes Custom Post
  Description: Freshcodes Custom Taxonomy(Portfolio, Staff, Testimonials,Home Main Slider) for freshcodes wordpress themes.
  Version: 1.0
  Author: Freshcodes
  Text Domain: freshcodes-custom-post
 */

// Freshcodes Portfolio

function portfolio_theme_custom_posts(){
	//Portfolio
	$labels = array(
	  'name' =>__('Portfolios','calibre'),
	  'singular_name' => __('Portfolio','calibre'),
	  'add_new' => __('Add New', 'calibre'),
	  'add_new_item' => __('Add New Portfolio item','calibre'),
	  'edit_item' => __('Edit Portfolio Item','calibre'),
	  'new_item' => __('New Portfolio Item','calibre'),
	  'view_item' => __('View Portfolio Item','calibre'),
	  'search_items' => __('Search Portfolio Item','calibre'),
	  'not_found' =>  __('No Portfolio item found','calibre'),
	  'not_found_in_trash' => __('No Portfolio item found in Trash','calibre'), 
	  'parent_item_colon' => ''
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true, 
	  'query_var' => true, 
	  'capability_type' => 'post', 
	  'menu_position' => null,
	  'menu_icon' => 'dashicons-images-alt2',
	  'rewrite' => array('slug'=>'portfolio','with_front'=>''),
	  'supports' => array('title','editor','author','thumbnail','comments')
	); 
	register_post_type('portfolio',$args);
	
// Portfolio Categories
	$labels = array(
	  'name' => __( 'Portfolio Categories','calibre'),
	  'singular_name' => __( 'Portfolio Category', 'calibre' ),
	  'search_items' =>  __( 'Search Portfolio Category' ,'calibre'),
	  'all_items' => __( 'All Portfolio Categories' ,'calibre'),
	  'parent_item' => __( 'Parent Portfolio Category' ,'calibre'),
	  'parent_item_colon' => __( 'Parent Portfolio Category:' ,'calibre'),
	  'edit_item' => __( 'Edit Portfolio Category','calibre' ), 
	  'update_item' => __( 'Update Portfolio Category' ,'calibre'),
	  'add_new_item' => __( 'Add New Portfolio Category','calibre' ),
	  'new_item_name' => __( 'New Genre Portfolio Category','calibre' ),
	); 	
	
	register_taxonomy('portfolio_categories',array('portfolio'), array(
	  'hierarchical' => true,
	  'labels' => $labels,
	  'show_ui' => true,
	  'query_var' => true,
	  '_builtin' => false,
	  'paged'=>true,
	  'rewrite' => false,
	));
}
add_filter('init', 'portfolio_theme_custom_posts' );

// Freshcodes Staff

function freshcodes_custom_post_staff(){
		$labels = array(
			'name' => __( 'Staff', 'calibre' ),
			'singular_name' => __( 'Staff','calibre' ),
			'add_new' => __( 'Add Staff','calibre' ),
			'add_new_item' => __( 'Add Staff ', 'calibre' ),
			'edit_item' => __( 'Edit Staff', 'calibre' ),
			'new_item' => __( 'New Staff', 'calibre' ),
			'view_item' => __( 'View Staff', 'calibre' ),
			'search_items' => __( 'Search Staff', 'calibre' ),
			'not_found' =>  __( 'No Staff found', 'calibre' ),
			'not_found_in_trash' => __( 'No Staff found in Trash', 'calibre' ), 
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true, 
			'query_var' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => null, 
			'menu_icon' => 'dashicons-groups',
			'taxonomies' => array( '' ), 
			'supports' => array( 'title', 'editor', 'page-attributes', 'thumbnail', 'excerpt')
		);
		
		register_post_type( 'staff', $args );	
}
add_filter( 'init', 'freshcodes_custom_post_staff' );
add_action( 'add_meta_boxes', 'staff_add_custom_fields' );
add_action( 'save_post', 'staff_save_custom_fields' );
function staff_add_custom_fields() {
    add_meta_box( 
        'staff_options',
        'Staff Details',
        'staff_inner_custom_field',
        'staff' 
    );
}
function staff_inner_custom_field( $post ) {
	// Use nonce for verification
	wp_nonce_field( plugin_basename( __FILE__ ), '_freshcodes' );	
	get_post_meta($post->ID, 'staff_position', TRUE) ? $staff_position = get_post_meta($post->ID, 'staff_position', TRUE) : $staff_position = '';
	get_post_meta($post->ID, 'staff_link', TRUE) ? $staff_link = get_post_meta($post->ID, 'staff_link', TRUE) : $staff_link = '';
	get_post_meta($post->ID, 'staff_email', TRUE) ? $staff_email = get_post_meta($post->ID, 'staff_email', TRUE) : $staff_email = '';
	get_post_meta($post->ID, 'staff_twitter', TRUE) ? $staff_twitter = get_post_meta($post->ID, 'staff_twitter', TRUE) : $staff_twitter = '';
	get_post_meta($post->ID, 'staff_facebook', TRUE) ? $staff_facebook = get_post_meta($post->ID, 'staff_facebook', TRUE) : $staff_facebook = '';
	get_post_meta($post->ID, 'staff_google_plus', TRUE) ? $staff_google_plus = get_post_meta($post->ID, 'staff_google_plus', TRUE) : $staff_google_plus = '';
	get_post_meta($post->ID, 'staff_linkedin', TRUE) ? $staff_linkedin = get_post_meta($post->ID, 'staff_linkedin', TRUE) : $staff_linkedin = '';
	get_post_meta($post->ID, 'staff_youtube', TRUE) ? $staff_youtube = get_post_meta($post->ID, 'staff_youtube', TRUE) : $staff_youtube = '';
	get_post_meta($post->ID, 'staff_rss', TRUE) ? $staff_rss = get_post_meta($post->ID, 'staff_rss', TRUE) : $staff_rss = '';
	get_post_meta($post->ID, 'staff_pinterest', TRUE) ? $staff_pinterest = get_post_meta($post->ID, 'staff_pinterest', TRUE) : $staff_pinterest = '';
	get_post_meta($post->ID, 'staff_skype', TRUE) ? $staff_skype = get_post_meta($post->ID, 'staff_skype', TRUE) : $staff_skype = '';	
?>
<table class="form-table">
	<tbody>
	<tr valign="top">
		<th><label for="staff_position">Position:</label></th>
		<td><input type="text" id="staff_position" name="staff_position" value="<?php echo esc_attr($staff_position); ?>" class="regular-text"/><br/>
		<span class="description">Enter the person's position or title (e.g. CEO, Manager etc.)</span> </td>
	</tr>
	<tr valign="top">
		<th><label for="staff_link">Personal blog / website:</label></th>
		<td><input type="text" id="staff_link" name="staff_link" value="<?php echo esc_attr($staff_link); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_email">Email:</label></th>
		<td><input type="text" id="staff_email" name="staff_email" value="<?php echo esc_attr($staff_email); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_twitter">Twitter:</label></th>
		<td><input type="text" id="staff_twitter" name="staff_twitter" value="<?php echo esc_attr($staff_twitter); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_facebook">Facebook:</label></th>
		<td><input type="text" id="staff_facebook" name="staff_facebook" value="<?php echo esc_attr($staff_facebook); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_google_plus">Google Plus:</label></th>
		<td><input type="text" id="staff_google_plus" name="staff_google_plus" value="<?php echo esc_attr($staff_google_plus); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_linkedin">Linkedin:</label></th>
		<td><input type="text" id="staff_linkedin" name="staff_linkedin" value="<?php echo esc_attr($staff_linkedin); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_youtube">Youtube:</label></th>
		<td><input type="text" id="staff_youtube" name="staff_youtube" value="<?php echo esc_attr($staff_youtube); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_rss">RSS:</label></th>
		<td><input type="text" id="staff_rss" name="staff_rss" value="<?php echo esc_attr($staff_rss); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_pinterest">Pinterest:</label></th>
		<td><input type="text" id="staff_pinterest" name="staff_pinterest" value="<?php echo esc_attr($staff_pinterest); ?>" class="regular-text" /></td>
	</tr>
	<tr valign="top">
		<th><label for="staff_skype">Skype:</label></th>
		<td><input type="text" id="staff_skype" name="staff_skype" value="<?php echo esc_attr($staff_skype); ?>" class="regular-text" /></td>
	</tr>	
	</tbody>
</table>
<?php }
function staff_save_custom_fields( $post_id ) {
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;
  if ( !current_user_can( 'edit_post', $post_id ) )
        return;
  $mydata = array();
  foreach($_POST as $key => $data) {
    if($key == '_freshcodes')
      continue;
	  
    if(preg_match('/^staff/i', $key)) {
      $mydata[$key] = $data;
	  update_post_meta($post_id, $key, $data);
    }
  }  
  return $mydata;
  
}


// Freshcodes Testimonials

function testimonial_theme_custom_posts(){
	//testimonial
	$labels = array(
	  'name' => __('Testimonials','calibre'),
	  'singular_name' => __('Testimonial','calibre'),
	  'add_new' => __('Add New','calibre'),
	  'add_new_item' => __('Add New Testimonial','calibre'),
	  'edit_item' => __('Edit Testimonial','calibre'),
	  'new_item' => __('New Testimonial','calibre'),
	  'view_item' => __('View Testimonial','calibre'),
	  'search_items' => __('Search Testimonial','calibre'),
	  'not_found' =>  __('No Testimonial found','calibre'),
	  'not_found_in_trash' => __('No Testimonial found in Trash','calibre'), 
	  'parent_item_colon' => ''
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true, 
	  'query_var' => true, 
	  'capability_type' => 'post', 
	  'menu_position' => null,
	  'menu_icon' => 'dashicons-format-chat',	 
	  'rewrite' => array('slug'=>'testimonial','with_front'=>''),
	  'supports' => array('title','editor','author','thumbnail','comments')
	); 
	register_post_type('testimonial',$args);	
}
add_filter('init', 'testimonial_theme_custom_posts' );
add_action( 'admin_init', 'remove_metabox_option' );
function remove_metabox_option() {
   	remove_meta_box( 'commentsdiv', 'testimonial', 'normal' );
	remove_meta_box( 'authordiv', 'testimonial', 'normal' );
	remove_meta_box( 'commentstatusdiv', 'testimonial', 'normal' );
}
add_action( 'add_meta_boxes', 'testimonial_add_custom_fields' );
add_action( 'save_post', 'testimonial_save_custom_fields' );
function testimonial_add_custom_fields() {
    add_meta_box( 
        'testimonial_options',
        'Testimonial Information',
        'testimonial_inner_custom_field',
        'testimonial' 
    );
}
function testimonial_inner_custom_field( $post ) {
	// Use nonce for verification
	wp_nonce_field( plugin_basename( __FILE__ ), '_freshcodes' );	
	get_post_meta($post->ID, 'testimonial_position', TRUE) ? $testimonial_position = get_post_meta($post->ID, 'testimonial_position', TRUE) : $testimonial_position = '';
	get_post_meta($post->ID, 'testimonial_link', TRUE) ? $testimonial_link = get_post_meta($post->ID, 'testimonial_link', TRUE) : $testimonial_link = '';
?>
<table class="form-table">
  <tbody>
    <tr valign="top">
      <th><label for="testimonial_position">
        <?php _e('Designation:', 'calibre'); ?>
        </label></th>
      <td><input type="text" id="testimonial_position" name="testimonial_position" value="<?php echo esc_attr($testimonial_position); ?>" class="regular-text"/></td>
    </tr>
    <tr valign="top">
      <th><label for="testimonial_link">
        <?php _e('Link:', 'calibre'); ?>
        </label></th>
      <td><input type="text" id="testimonial_link" name="testimonial_link" value="<?php echo esc_attr($testimonial_link); ?>" class="regular-text" /></td>
    </tr>
  </tbody>
</table>
<?php }
function testimonial_save_custom_fields( $post_id ) {
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;
  if ( !current_user_can( 'edit_post', $post_id ) )
        return;
  $mydata = array();
  foreach($_POST as $key => $data) {
    if($key == '_freshcodes')
      continue;
	  
    if(preg_match('/^testimonial/i', $key)) {
      $mydata[$key] = $data;
	  update_post_meta($post_id, $key, $data);
    }
  }
 
  return $mydata;  
}

// Freshcodes Brand
function brand_theme_custom_posts(){

$permalinks = get_option( 'woocommerce_permalinks' );
register_taxonomy( 'product_brand',
			apply_filters( 'woocommerce_taxonomy_objects_product_brand', array( 'product' ) ),
			apply_filters( 'woocommerce_taxonomy_args_product_brand', array(
				'hierarchical'          => true,
				'update_count_callback' => '_wc_term_recount',
				'label'                 => __( 'Product Brand', 'woocommerce' ),
				'labels' => array(
						'name'              => __( 'Product Brand', 'woocommerce' ),
						'singular_name'     => __( 'Product Brand', 'woocommerce' ),
						'menu_name'         => _x( 'Brands', 'Admin menu name', 'woocommerce' ),
						'search_items'      => __( 'Search Brand', 'woocommerce' ),
						'all_items'         => __( 'All Brand', 'woocommerce' ),
						'parent_item'       => __( 'Parent Brand', 'woocommerce' ),
						'parent_item_colon' => __( 'Parent  Brand:', 'woocommerce' ),
						'edit_item'         => __( 'Edit Brand', 'woocommerce' ),
						'update_item'       => __( 'Update Brand', 'woocommerce' ),
						'add_new_item'      => __( 'Add New Brand', 'woocommerce' ),
						'new_item_name'     => __( 'New Brand Name', 'woocommerce' ),
						'not_found'         => __( 'No Brand found', 'woocommerce' ),
						
							'featured_image'        => __( 'Product Image', 'woocommerce' ),
							'set_featured_image'    => __( 'Set product image', 'woocommerce' ),
							'remove_featured_image' => __( 'Remove product image', 'woocommerce' ),
							'use_featured_image'    => __( 'Use as product image', 'woocommerce' ),
							'insert_into_item'      => __( 'Insert into product', 'woocommerce' ),
							'uploaded_to_this_item' => __( 'Uploaded to this product', 'woocommerce' ),
					),
				'show_ui'               => true,
				'query_var'             => true,
				'capabilities'          => array(
					'manage_terms' => 'manage_product_terms',
					'edit_terms'   => 'edit_product_terms',
					'delete_terms' => 'delete_product_terms',
					'assign_terms' => 'assign_product_terms',
				),
				'rewrite'               => array(
					'slug'         => empty( $permalinks['brand_base'] ) ? _x( 'product-brand', 'slug', 'woocommerce' ) : $permalinks['brand_base'],
					'with_front'   => false,
					'hierarchical' => true,
				),
			) )
		);
	}
add_filter('init', 'brand_theme_custom_posts' );
function __construct() {
		// Brand/term ordering
		add_action( 'create_term', array( $this, 'create_term' ), 5, 3 );
		add_action( 'delete_term', array( $this, 'delete_term' ), 5 );

		// Add form
		add_action( 'product_brand_add_form_fields', array( $this, 'add_Brand_fields' ) );
		add_action( 'product_brand_edit_form_fields', array( $this, 'edit_Brand_fields' ), 10 );
		add_action( 'created_term', array( $this, 'save_Brand_fields' ), 10, 3 );
		add_action( 'edit_term', array( $this, 'save_Brand_fields' ), 10, 3 );

		// Add columns
		add_filter( 'manage_edit-product_brand_columns', array( $this, 'product_brand_columns' ) );
		add_filter( 'manage_product_brand_custom_column', array( $this, 'product_brand_column' ), 10, 3 );

		// Taxonomy page descriptions
		add_action( 'product_brand_pre_add_form', array( $this, 'product_brand_description' ) );

		$attribute_taxonomies = wc_get_attribute_taxonomies();
}
?>